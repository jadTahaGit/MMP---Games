from Vector import Vector

vector1 = Vector(10.0,20.0)
print(vector1)

print(Vector.vector_from_points((10,10), (30,10)))
