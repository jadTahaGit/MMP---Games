print("Who stole my Monkey?") # weird but I‘ll let it in
a = 1
b = 2
print(a + b) # I hope it‘ll output 3

# print "bye“
