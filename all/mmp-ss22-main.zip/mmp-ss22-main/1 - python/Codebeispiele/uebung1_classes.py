class HelloWorld:
    def __init__(self):
        print("Hello World")

    def test(self):
        print("testus")

a = HelloWorld()
a.test()
