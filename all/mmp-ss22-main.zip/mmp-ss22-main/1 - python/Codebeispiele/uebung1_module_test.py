def a():
    print("there we are")


def b():
    print("function b")
