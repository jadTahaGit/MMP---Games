a = [1,3,"a","b"]

for x in a:
    print(x)

#while True:
#   print("This will never end. :-s")
