a = "hello"
print(a[0])
print(a[0:])
print(a[0:2])
print(a[0:len(a)])
print(a[2:])
print(a[:2])
print(a[2:4])
print(a[-1])

print("""lalala
test: 
        aha""")

print("lalala\ntest")

print(r"lalala\ntest")


