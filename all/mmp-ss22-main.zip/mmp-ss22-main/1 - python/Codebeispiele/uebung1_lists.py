a = [1,3,"a","b"]
print(a)
print(a[0])

a[0] = 2
print(a)

print(2 * a)
