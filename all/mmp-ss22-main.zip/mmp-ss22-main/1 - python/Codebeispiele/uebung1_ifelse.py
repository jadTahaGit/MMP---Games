a = 0
if a > 0:
    print("a>0")
elif a == 0:
    print("a=0")
else:
    print("none")
