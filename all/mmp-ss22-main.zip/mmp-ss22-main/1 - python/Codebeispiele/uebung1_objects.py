def b():
    x = 0
    print(x)


print(type(b))
b = 4
print(type(b))

print(isinstance(b, int))
