from uebung1_module_test import a

a()
