priceDict = {'mehl': 99, 'butter': 78}

print(priceDict['mehl'])
print(priceDict.keys())

priceDict['oel'] = 112

print('oel' in priceDict)
